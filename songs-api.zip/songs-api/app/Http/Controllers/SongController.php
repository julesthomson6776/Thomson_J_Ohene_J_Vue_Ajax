<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Song; // Import the Song model

class SongController extends Controller {
    /**
     * Create a new controller instance.
     *
     * @return void
     */

     public function getAll() {
         $songs = Song::all();
         return response()->json($songs);
     }

     public function getOne($id) {
         $song = Song::find($id);
         return response()->json($song);
     }

     public function save(Request $request) {
        $this->validate($request, [
            'albumname' => 'required',
            'albumpicture' => 'required',
            'filename,' => 'required',
            'artist'=>'required',
            'toptracks,' => 'required'  
        ]);
        $song = Song::create($request->all());
        return response()->json($song, 201);
    }
    
    public function update(Request $request, $id) {
        $song = Song::findOrFail($id);
    
        $this->validate($request, [
            'albumname' => 'required',
            'albumpicture' => 'required',
            'filename,' => 'required',
            'artist'=>'required',
            'toptracks,' => 'required' 
        ]);
        $song->update($request->all());
        return response()->json($song);
    }
    
    public function delete($id) {
        $song = Song::findOrFail($id);
        $song->delete();
        return response()->json(null, 204);
    }
}
